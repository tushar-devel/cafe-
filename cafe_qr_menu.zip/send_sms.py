import os
from twilio.rest import Client

account_sid = os.getenv("ACCOUNT_SID")
auth_token = os.getenv("AUTH_TOKEN")
twilio_number = os.getenv("TWILIO_NUMBER")
owner_number = os.getenv("OWNER_NUMBER")

def send_sms(name, phone):
    client = Client(account_sid, auth_token)
    message = client.messages.create(
        body=f"New customer:\nName: {name}\nPhone: {phone}",
        from_=twilio_number,
        to=owner_number
    )
    print("SMS sent:", message.sid)
